# eb-django-express-signup

This repository contains the Python 3.x code base of a small web application for a [tutorial](../../../Assignments-2020/blob/master/Lab04.md) that instructs on how to deploy a web app on PaaS **AWS Beanstalk**. The web app interacts with **Amazon DynamoDB**, **Amazon Simple Notification Service** and **Amazon Cloud Front**.

*eb-django-express-signup* follows the popular Python framework [Django](https://www.djangoproject.com/).
